# Aurelia Painting — Next.js Starter

This project is a ready-to-deploy Next.js App Router site for Aurelia Painting.

Commands:

- `npm install` to install dependencies
- `npm run dev` to run locally
- `npm run build` then `npm start` to run production

Deploy to Vercel by connecting the repository or uploading this project folder.