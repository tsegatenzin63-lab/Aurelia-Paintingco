import { ChevronDown } from 'lucide-react'
export default function IconChevronDown(props) { return <ChevronDown {...props} /> }
