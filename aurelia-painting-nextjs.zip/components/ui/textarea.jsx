import React from 'react'

export default function Textarea(props) {
  return <textarea {...props} />
}
